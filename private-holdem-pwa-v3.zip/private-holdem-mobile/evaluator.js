'use strict';
const R='23456789TJQKA', S='shdc';
function deck(){return [...S].flatMap(s=>[...R].map(r=>r+s));}
function five(cards){
 const ranks=cards.map(c=>R.indexOf(c[0])+2), suits=cards.map(c=>c[1]);
 const counts=new Map(); for(const r of ranks)counts.set(r,(counts.get(r)||0)+1);
 const unique=[...new Set(ranks)].sort((a,b)=>b-a);
 let straight=0; const run=unique.includes(14)?[...unique,1]:unique;
 for(let i=0;i<=run.length-5;i++)if(run[i]-run[i+4]===4){straight=run[i];break;}
 const flush=suits.every(s=>s===suits[0]);
 const groups=[...counts].map(([r,n])=>({r,n})).sort((a,b)=>b.n-a.n||b.r-a.r);
 const byCount=n=>groups.filter(g=>g.n===n).map(g=>g.r);
 if(flush&&straight)return [8,straight];
 if(groups[0].n===4)return [7,groups[0].r,...byCount(1)];
 if(groups[0].n===3&&groups[1].n===2)return [6,groups[0].r,groups[1].r];
 if(flush)return [5,...unique];
 if(straight)return [4,straight];
 if(groups[0].n===3)return [3,groups[0].r,...byCount(1)];
 if(groups[0].n===2&&groups[1].n===2)return [2,...byCount(2),...byCount(1)];
 if(groups[0].n===2)return [1,groups[0].r,...byCount(1)];
 return [0,...unique];
}
function cmp(a,b){for(let i=0;i<Math.max(a.length,b.length);i++){let x=(a[i]||0)-(b[i]||0);if(x)return Math.sign(x);}return 0;}
function evaluate(cards){if(cards.length<5||cards.length>7)throw Error('Need 5-7 cards');let best=null;for(let a=0;a<cards.length-4;a++)for(let b=a+1;b<cards.length-3;b++)for(let c=b+1;c<cards.length-2;c++)for(let d=c+1;d<cards.length-1;d++)for(let e=d+1;e<cards.length;e++){const x=five([cards[a],cards[b],cards[c],cards[d],cards[e]]);if(!best||cmp(x,best)>0)best=x;}return best;}
module.exports={deck,evaluate,cmp};
