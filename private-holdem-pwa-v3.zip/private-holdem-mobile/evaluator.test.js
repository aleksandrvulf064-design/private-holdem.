const test=require('node:test'),assert=require('node:assert/strict'),{evaluate,cmp}=require('./evaluator');
test('royal flush beats quads',()=>assert.ok(cmp(evaluate(['As','Ks','Qs','Js','Ts','2d','3c']),evaluate(['Ah','Ad','Ac','As','2h','3d','4c']))>0));
test('wheel straight is five high',()=>assert.deepEqual(evaluate(['As','2h','3c','4d','5s','9h','Td']),[4,5]));
test('best full house chosen',()=>assert.deepEqual(evaluate(['As','Ah','Ad','Ks','Kh','Kd','2s']),[6,14,13]));
test('tie hands',()=>assert.equal(cmp(evaluate(['As','Ks','Qs','Js','Ts']),evaluate(['Ah','Kh','Qh','Jh','Th'])),0));
