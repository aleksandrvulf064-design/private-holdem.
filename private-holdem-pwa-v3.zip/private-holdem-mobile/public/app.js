const socket=io(),$=id=>document.getElementById(id);let state=null,credentials=null;
const saved=()=>{try{return JSON.parse(localStorage.getItem('holdemSession'))}catch{return null}};
function toast(t){$('toast').textContent=t;$('toast').style.display='block';setTimeout(()=>$('toast').style.display='none',3300)}
function send(event,data,cb){socket.emit(event,data,res=>{if(!res?.ok)return toast(res?.error||'Ошибка связи');cb?.(res)})}
function enter(r){credentials={id:r.id,pid:r.pid,secret:r.secret};localStorage.setItem('holdemSession',JSON.stringify(credentials));$('lobby').hidden=true;$('game').hidden=false;history.replaceState(null,'','/?room='+r.id)}
$('create').onclick=()=>send('create',{name:$('name').value},enter);
$('join').onclick=()=>send('join',{id:$('code').value,name:$('name').value},enter);
$('invite').onclick=async()=>{const url=location.origin+'/?room='+state.id;try{await navigator.clipboard.writeText(url);toast('Ссылка скопирована')}catch{prompt('Скопируйте ссылку',url)}};
$('start').onclick=()=>send('start',{});
function action(type,amount){send('action',{type,amount})}
document.querySelectorAll('[data-action]').forEach(b=>b.onclick=()=>action(b.dataset.action));
$('raise').onclick=()=>action('raise',Number($('raiseAmount').value));$('allin').onclick=()=>action('allin');
const suit={s:'♠',h:'♥',d:'♦',c:'♣'};function card(c){if(!c)return '';return `<div class="card ${'hd'.includes(c[1])?'red':''}">${c[0]==='T'?'10':c[0]}${suit[c[1]]}</div>`}
function render(s){state=s;$('roomCode').textContent=s.id;$('stage').textContent=({waiting:'Ожидание игроков',preflop:'Префлоп',flop:'Флоп',turn:'Тёрн',river:'Ривер',showdown:'Результаты раздачи'})[s.phase];$('pot').textContent='Банк '+s.pot.toLocaleString('ru-RU');$('board').innerHTML=s.board.map(card).join('');
 const me=s.players.find(p=>p.id===s.me),turn=s.players[s.turn],call=me?Math.max(0,s.streetBet-me.bet):0;
 $('mycards').innerHTML=(me?.cards||[]).map(card).join('');$('stack').textContent=(me?.stack||0).toLocaleString('ru-RU')+' фишек';
 $('notice').textContent=s.phase==='showdown'?s.players.filter(p=>p.win).map(p=>`${p.name} выиграл ${p.win}`).join(' · '):turn?'Ход: '+turn.name:'Пригласите друзей';
 $('players').innerHTML=s.players.map((p,i)=>{const a=(i/s.players.length)*2*Math.PI-Math.PI/2,x=50+38*Math.cos(a),y=50+39*Math.sin(a);return `<div class="player ${s.turn===i?'turn':''} ${p.folded?'folded':''}" style="left:${x}%;top:${y}%"><b>${escapeHtml(p.name)}${s.button===i?' Ⓓ':''}</b><div class="chips">${p.stack.toLocaleString('ru-RU')} ●</div><div class="status">${p.win?'+'+p.win:p.bet?'Ставка '+p.bet:p.allin?'ОЛЛ-ИН':!p.connected?'Отключён':p.folded?'Пас':''}</div>${p.cards.length&&p.id!==s.me?`<div style="font-size:12px">${p.cards.map(c=>c[0]+suit[c[1]]).join(' ')}</div>`:p.hasCards?'🂠 🂠':''}</div>`}).join('');
 $('start').hidden=!(s.owner&&s.canStart);$('betting').hidden=!(turn?.id===s.me&&s.phase!=='showdown');$('check').disabled=call>0;$('call').textContent=call?'Колл '+Math.min(call,me?.stack||0):'Чек';$('call').disabled=!call;
 $('raiseAmount').min=s.streetBet+s.minRaise;$('raiseAmount').max=(me?.stack||0)+(me?.bet||0);$('raiseAmount').value=Math.min(Number($('raiseAmount').max),Number($('raiseAmount').min));
 $('raise').disabled=Number($('raiseAmount').min)>Number($('raiseAmount').max);$('allin').disabled=!(me?.stack);
 $('log').innerHTML=s.log.map(l=>'<div>'+escapeHtml(l)+'</div>').join('');}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
socket.on('state',render);socket.on('connect',()=>{const r=saved();if(r)send('join',r,enter)});
const params=new URLSearchParams(location.search);if(params.get('room'))$('code').value=params.get('room').toUpperCase();

socket.on('disconnect',()=>toast('Нет связи с сервером. Переподключаемся…'));
socket.on('connect_error',()=>toast('Сервер недоступен. Проверьте подключение.'));
