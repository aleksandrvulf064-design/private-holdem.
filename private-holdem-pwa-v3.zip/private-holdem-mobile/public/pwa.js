(() => {
  if ('serviceWorker' in navigator) window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(()=>{}));
  let deferred=null;
  const bar=document.getElementById('installBar'),install=document.getElementById('installButton'),dismiss=document.getElementById('dismissInstall');
  const standalone=window.matchMedia('(display-mode: standalone)').matches||window.navigator.standalone===true;
  const isiOS=/iPad|iPhone|iPod/.test(navigator.userAgent);
  if(!standalone&&isiOS&&!sessionStorage.getItem('hideInstall')){bar.hidden=false;install.textContent='Как установить';}
  window.addEventListener('beforeinstallprompt',event=>{event.preventDefault();deferred=event;if(!sessionStorage.getItem('hideInstall'))bar.hidden=false;});
  install.addEventListener('click',async()=>{if(deferred){const prompt=deferred;deferred=null;bar.hidden=true;await prompt.prompt();}else if(isiOS){alert('В Safari нажмите «Поделиться» → «На экран Домой» → «Добавить».');}});
  dismiss.addEventListener('click',()=>{bar.hidden=true;sessionStorage.setItem('hideInstall','1');});
  window.addEventListener('appinstalled',()=>{bar.hidden=true;deferred=null;});
})();