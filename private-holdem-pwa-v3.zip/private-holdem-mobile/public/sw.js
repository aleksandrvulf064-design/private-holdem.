/* Static assets only. Never cache socket traffic or private game state. */
const CACHE='private-holdem-static-v3';
const ASSETS=['/','/index.html','/style.css','/app.js','/pwa.js','/manifest.webmanifest','/icons/icon-192.png','/icons/icon-512.png','/offline.html'];
self.addEventListener('install',event=>{event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(ASSETS)).then(()=>self.skipWaiting()));});
self.addEventListener('activate',event=>{event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));});
self.addEventListener('fetch',event=>{const req=event.request;const url=new URL(req.url);if(req.method!=='GET'||url.origin!==self.location.origin||url.pathname.startsWith('/socket.io/')||url.pathname==='/health')return;
 if(req.mode==='navigate'){event.respondWith(fetch(req).catch(()=>caches.match('/offline.html')));return;}
 if(ASSETS.includes(url.pathname)){event.respondWith(caches.match(req).then(cached=>cached||fetch(req)));}
});
