'use strict';
const express=require('express'),http=require('http'),crypto=require('crypto');
const {Server}=require('socket.io');const {deck,evaluate,cmp}=require('./evaluator');
const app=express(),server=http.createServer(app),io=new Server(server,{maxHttpBufferSize:10000,cors:{origin:true,methods:['GET','POST']}});
app.disable('x-powered-by');app.use((req,res,next)=>{res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','strict-origin-when-cross-origin');res.setHeader('X-Frame-Options','DENY');if(req.path==='/sw.js')res.setHeader('Cache-Control','no-cache');next();});app.use(express.static('public'));app.get('/health',(_req,res)=>res.json({ok:true,service:'private-holdem',version:'2.0.0'}));
const rooms=new Map(), START=10000, SB=50, BB=100, MAX=9;
const token=()=>crypto.randomBytes(18).toString('hex');
const roomId=()=>crypto.randomBytes(4).toString('hex').toUpperCase();
function participants(r){return r.players.filter(p=>p.stack>0&&p.connected);}
function nextIndex(r,from,filter){for(let k=1;k<=r.players.length;k++){const i=(from+k+r.players.length)%r.players.length;if(filter(r.players[i]))return i;}return -1;}
function broadcast(r){for(const p of r.players){if(!p.sid)continue;io.to(p.sid).emit('state',view(r,p));}}
function view(r,me){return {id:r.id,host:r.host,phase:r.phase,board:r.board,pot:r.players.reduce((a,p)=>a+p.total,0),button:r.button,turn:r.turn,streetBet:r.streetBet,minRaise:r.minRaise,hand:r.hand,log:r.log.slice(-12),players:r.players.map((p,i)=>({id:p.id,name:p.name,seat:i,stack:p.stack,bet:p.bet,total:p.total,folded:p.folded,allin:p.allin,connected:p.connected,hasCards:p.cards.length===2,cards:p.id===me.id?p.cards:(r.phase==='showdown'&&p.reveal?p.cards:[]),win:p.win||0})),me:me.id,owner:me.id===r.host,canStart:r.phase==='waiting'&&participants(r).length>=2,smallBlind:SB,bigBlind:BB};}
function log(r,s){r.log.push(s);if(r.log.length>40)r.log.shift();}
function shuffle(){const d=deck();for(let i=d.length-1;i>0;i--){const j=crypto.randomInt(i+1);[d[i],d[j]]=[d[j],d[i]];}return d;}
function contribute(p,n){n=Math.min(n,p.stack);p.stack-=n;p.bet+=n;p.total+=n;if(!p.stack)p.allin=true;return n;}
function live(r){return r.players.filter(p=>p.cards.length&&!p.folded);}
function actionable(p){return p.cards.length&&!p.folded&&!p.allin&&p.connected;}
function chooseTurn(r,after){r.turn=nextIndex(r,after,actionable);}
function begin(r){
 if(r.phase!=='waiting'&&r.phase!=='showdown')return;
 const active=participants(r);if(active.length<2)return;
 r.hand++;r.phase='preflop';r.board=[];r.log=[];r.streetBet=0;r.minRaise=BB;
 for(const p of r.players){p.cards=[];p.bet=0;p.total=0;p.folded=false;p.allin=false;p.acted=false;p.reveal=false;p.win=0;}
 r.button=nextIndex(r,r.button,p=>p.stack>0&&p.connected);
 const sb=active.length===2?r.button:nextIndex(r,r.button,p=>p.stack>0&&p.connected);
 const bb=nextIndex(r,sb,p=>p.stack>0&&p.connected);
 r.deck=shuffle();for(const p of r.players)if(p.stack>0&&p.connected)p.cards=[r.deck.pop(),r.deck.pop()];
 contribute(r.players[sb],SB);contribute(r.players[bb],BB);
 r.streetBet=Math.max(r.players[sb].bet,r.players[bb].bet);
 chooseTurn(r,bb);log(r,`Раздача №${r.hand}. Блайнды ${SB}/${BB}`);
 if(r.turn<0)advance(r);else broadcast(r);
}
function resetStreet(r){for(const p of r.players){p.bet=0;p.acted=false;}r.streetBet=0;r.minRaise=BB;}
function distribute(r){
 const contenders=live(r),levels=[...new Set(r.players.map(p=>p.total).filter(x=>x>0))].sort((a,b)=>a-b);
 let prev=0;for(const level of levels){const contributors=r.players.filter(p=>p.total>=level);const amount=(level-prev)*contributors.length;prev=level;
 const eligible=contenders.filter(p=>p.total>=level);if(!eligible.length)continue;
 let winners=[eligible[0]],best=evaluate([...eligible[0].cards,...r.board]);
 for(const p of eligible.slice(1)){const v=evaluate([...p.cards,...r.board]),c=cmp(v,best);if(c>0){winners=[p];best=v;}else if(!c)winners.push(p);}
 const share=Math.floor(amount/winners.length),rem=amount%winners.length;
 // Odd chips awarded clockwise from button.
 winners.sort((a,b)=>((r.players.indexOf(a)-r.button+r.players.length)%r.players.length)-((r.players.indexOf(b)-r.button+r.players.length)%r.players.length));
 winners.forEach((p,i)=>{const n=share+(i<rem?1:0);p.stack+=n;p.win+=n;});
 }
 log(r,`Победители: ${r.players.filter(p=>p.win).map(p=>`${p.name} +${p.win}`).join(', ')}`);
}
function finish(r){r.phase='showdown';r.turn=-1;
 if(live(r).length===1){const p=live(r)[0],amount=r.players.reduce((a,x)=>a+x.total,0);p.stack+=amount;p.win=amount;log(r,`${p.name} забирает банк ${amount}`);}
 else {while(r.board.length<5)r.board.push(r.deck.pop());live(r).forEach(p=>p.reveal=true);distribute(r);}
 broadcast(r);
}
function advance(r){if(live(r).length<=1){finish(r);return;}
 const able=r.players.filter(actionable);
 if(!able.length|| (able.length===1&&able[0].bet===r.streetBet)){while(r.board.length<5)r.board.push(r.deck.pop());finish(r);return;}
 if(r.phase==='river'){finish(r);return;}
 resetStreet(r);if(r.phase==='preflop'){r.phase='flop';r.board.push(r.deck.pop(),r.deck.pop(),r.deck.pop());}
 else if(r.phase==='flop'){r.phase='turn';r.board.push(r.deck.pop());}
 else {r.phase='river';r.board.push(r.deck.pop());}
 chooseTurn(r,r.button);log(r,`Улица: ${r.phase}`);
 if(r.turn<0)advance(r);else broadcast(r);
}
function act(r,p,type,amount){if(r.turn<0||r.players[r.turn]!==p||!actionable(p))throw Error('Сейчас не ваш ход');
 const toCall=Math.max(0,r.streetBet-p.bet);let fullRaise=false;
 if(type==='fold'){p.folded=true;log(r,`${p.name}: пас`);}
 else if(type==='check'){if(toCall)throw Error('Нельзя чекнуть: есть ставка');log(r,`${p.name}: чек`);}
 else if(type==='call'){contribute(p,toCall);log(r,`${p.name}: колл`);}
 else if(type==='raise'||type==='allin'){
  const target=type==='allin'?p.bet+p.stack:Math.floor(Number(amount));
  if(type==='allin'&&target<=r.streetBet){contribute(p,p.stack);p.acted=true;log(r,`${p.name}: олл-ин ${p.bet}`);if(live(r).length===1){finish(r);return;}const pending=r.players.some(q=>actionable(q)&&(!q.acted||q.bet<r.streetBet));if(!pending)advance(r);else {chooseTurn(r,r.players.indexOf(p));if(r.turn<0)advance(r);else broadcast(r);}return;}
  if(!Number.isSafeInteger(target)||target<=r.streetBet||target>p.bet+p.stack)throw Error('Недопустимый размер ставки');
  const increase=target-r.streetBet;
  if(increase<r.minRaise&&target!==p.bet+p.stack)throw Error(`Минимальный рейз до ${r.streetBet+r.minRaise}`);
  if(p.acted&&increase<r.minRaise)throw Error('Неполный олл-ин не открывает повторный рейз');
  contribute(p,target-p.bet);if(increase>=r.minRaise){r.minRaise=increase;fullRaise=true;}
  r.streetBet=Math.max(r.streetBet,p.bet);log(r,`${p.name}: ${type==='allin'?'олл-ин':'рейз'} до ${p.bet}`);
 }else throw Error('Неизвестное действие');
 p.acted=true;if(fullRaise)for(const q of r.players)if(q!==p&&actionable(q))q.acted=false;
 if(live(r).length===1){finish(r);return;}
 const pending=r.players.some(q=>actionable(q)&&(!q.acted||q.bet<r.streetBet));
 if(!pending){advance(r);return;}
 chooseTurn(r,r.players.indexOf(p));if(r.turn<0)advance(r);else broadcast(r);
}
function reply(ack,err,data){if(typeof ack==='function')ack(err?{ok:false,error:err.message||String(err)}:{ok:true,...(data||{})});}
function findPlayer(r,id){return r.players.find(p=>p.id===id);}
io.on('connection',socket=>{
 socket.on('create',({name}={},ack)=>{try{const id=roomId(),pid=token(),secret=token();const p={id:pid,secret,name:String(name||'Игрок').trim().slice(0,22)||'Игрок',sid:socket.id,connected:true,stack:START,cards:[],bet:0,total:0};const r={id,host:pid,players:[p],phase:'waiting',hand:0,button:-1,turn:-1,board:[],streetBet:0,minRaise:BB,log:[]};rooms.set(id,r);socket.data={id,pid};socket.join(id);reply(ack,null,{id,pid,secret});broadcast(r);}catch(e){reply(ack,e);}});
 socket.on('join',({id,name,pid,secret}={},ack)=>{try{id=String(id||'').toUpperCase();const r=rooms.get(id);if(!r)throw Error('Комната не найдена');let p=pid&&findPlayer(r,pid);if(p){if(p.secret!==secret)throw Error('Неверный ключ восстановления');if(p.sid&&p.sid!==socket.id)io.sockets.sockets.get(p.sid)?.disconnect(true);p.sid=socket.id;p.connected=true;}
 else {if(r.phase!=='waiting'&&r.phase!=='showdown')throw Error('Раздача идёт. Подключитесь после её завершения');if(r.players.length>=MAX)throw Error('Стол заполнен');pid=token();secret=token();p={id:pid,secret,name:String(name||'Игрок').trim().slice(0,22)||'Игрок',sid:socket.id,connected:true,stack:START,cards:[],bet:0,total:0};r.players.push(p);}
 socket.data={id,pid:p.id};socket.join(id);reply(ack,null,{id,pid:p.id,secret:p.secret});broadcast(r);
 }catch(e){reply(ack,e);}});
 socket.on('start',(_,ack)=>{try{const {id,pid}=socket.data||{},r=rooms.get(id);if(!r||r.host!==pid)throw Error('Только создатель комнаты запускает раздачу');if(r.phase!=='waiting'&&r.phase!=='showdown')throw Error('Раздача уже идёт');if(participants(r).length<2)throw Error('Нужно минимум два игрока');begin(r);reply(ack);}catch(e){reply(ack,e);}});
 socket.on('action',({type,amount}={},ack)=>{try{const {id,pid}=socket.data||{},r=rooms.get(id),p=r&&findPlayer(r,pid);if(!p)throw Error('Игрок не найден');act(r,p,type,amount);reply(ack);}catch(e){reply(ack,e);}});
 socket.on('disconnect',()=>{const {id,pid}=socket.data||{},r=rooms.get(id),p=r&&findPlayer(r,pid);if(!p||p.sid!==socket.id)return;p.connected=false;p.sid=null;if(r.turn>=0&&r.players[r.turn]===p){p.folded=true;p.acted=true;log(r,`${p.name} отключился и сбросил карты`);if(live(r).length<=1)finish(r);else if(!r.players.some(q=>actionable(q)&&(!q.acted||q.bet<r.streetBet)))advance(r);else {chooseTurn(r,r.players.indexOf(p));if(r.turn<0)advance(r);}}broadcast(r);});
});
const PORT=process.env.PORT||3000;if(require.main===module)server.listen(PORT,'0.0.0.0',()=>console.log(`Poker: http://localhost:${PORT}`));module.exports={app,server,io,rooms,begin,act,finish,advance};
